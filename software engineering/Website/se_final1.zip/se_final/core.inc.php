<?php
require 'connect.db.php';
require 'chat.func.php';

?>