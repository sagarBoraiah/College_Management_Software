<?php
	session_start();
	if(!isset($_SESSION["sess_user"])){
		header("location:login.php");
	}
	else
	{
		require 'core.inc.php';
		$sender=$_SESSION['sess_user'];
		?>
			

		<!DOCTYPE html>
		<html lang="en">
		<head>
		  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		   
			<meta name="viewport" content="width=device-width, initial-scale=1">
		   
		   

			<title>College Management System</title>

			<link href="bootstrap.css" rel="stylesheet">

		  </head>

		  <body style="">

			<!-- Static navbar -->
			<div class="navbar navbar-inverse navbar-static-top" role="navigation">
			  <div class="container">
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				  <a class="navbar-brand" href="main.php">College Management System</a>
				</div>
				<div class="navbar-collapse collapse">
				  <ul class="nav navbar-nav">
					<li ><a href="main.php">Announcements</a></li>
					<li><a href="attendance.php">Attendance</a></li>
					<li  class="active"><a href="timetable.php">Timetable</a></li>
					<li ><a href="calendar.php">Calendar</a></li>
				  </ul>
				  <ul class="nav navbar-nav navbar-right">
					<li><a href="#">About</a></li>
					
					<li><a href="logout.php">Log Out</a></li>
				  </ul>
				</div>
			  </div>
			</div>


			<div class="container">

			 
			  <div class="jumbotron">
				<h2 style="margin-left:40%;">Timetable</h2>
			  </div>
			  <div id="timtable" style="margin-left:-10%;">
				  <table class="table table-bordered">
				<thead>
				  <tr>
					<th>#</th>
					<th>7:55 - 8:50</th>
					<th>8:55 - 9:50</th>
					<th>10:05 - 11:00</th>
					<th>11:05 - 12:00</th>
					<th>1:05 - 2:00</th>
					<th>2:05 - 3:00</th>
					<th>3:05 - 4:00</th>
					<th>4:05 - 5:00</th>
				  </tr>
				</thead>
				<tbody>
				  <tr>
					<td>1</td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
				   <td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					
				  </tr>
				   <tr>
					<td>2</td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
				   <td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					
				  </tr>
				  <tr>
					<td>3</td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
				   <td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					
				  </tr>
				  <tr>
					<td>4</td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
				   <td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					
				  </tr>
				  <tr>
					<td>5</td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					<td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
				   <td><input type="text" id="exampleInputEmail1" placeholder="Enter subject"></td>
					
				  </tr>
				  

				</tbody>
			  </table>
			
			  </div>
		  
			<button class="btn btn-lg btn-success" style="margin-left:40%;">Save</button>
		   
			<script src="jquery.js"></script>
			<script src="bootstrap.js"></script>
		  

		</body></html>
	<?php
	}
?>